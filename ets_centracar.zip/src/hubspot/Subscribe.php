<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot;

/**
 * Description of Subscribe
 *
 * @author Christophe
 */
class Subscribe extends NewsLetterForm {

    protected $formId = 'b43e43db-63b1-4425-9f7c-3084a68d5209'; //mandatory

    protected $formName = 'Inscription'; // send to hubspot

    protected $varsMapping = [
        'postVars\acf\field_5b4767ffa0cf3'    => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'firstname'          , 'format' =>\eteamsys\hubspot\Converter\UCfirstConverter::class ],
        'postVars\acf\field_5b4767cca0cf2'    => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'lastname'           , 'format' =>\eteamsys\hubspot\Converter\UpperCaseConverter::class ],
        'postVars\acf\field_5b48638ce2748'    => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'nom_d_utilisateur'  , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],
    ];

}
