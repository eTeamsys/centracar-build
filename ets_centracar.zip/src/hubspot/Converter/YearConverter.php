<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot\Converter;

/**
 * Description of YearConverter
 *
 * @author Christophe
 */
class YearConverter implements \eteamsys\hubspot\Converter\ConverterInterface {
    
    public function convert($value) {
        
        return substr($value, 0 , 4);
        
    }
    
}
