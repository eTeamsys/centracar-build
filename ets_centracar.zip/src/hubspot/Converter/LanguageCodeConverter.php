<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot\Converter;

/**
 * Description of LangaugeCodeConverter
 *
 * @author Christophe
 */
class LanguageCodeConverter implements \eteamsys\hubspot\Converter\ConverterInterface {
    
    public function convert($value){
        $code = substr($value, 0, 2);
        return strtoupper($code);
    }

}
