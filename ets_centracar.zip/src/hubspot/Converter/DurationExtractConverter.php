<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace eteamsys\centracar\hubspot\Converter;
/**
 * Description of DurationExtractConverter
 *
 * @author Christophe
 */
class DurationExtractConverter implements \eteamsys\hubspot\Converter\ConverterInterface {

    /**
     * return formated value
     * @param $value
     * @return $formated
     */
    public function convert($value) {
        return intval($value) * 12;
    }

}