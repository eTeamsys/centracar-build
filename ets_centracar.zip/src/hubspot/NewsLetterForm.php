<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot;

use eteamsys\hubspot\form\SubmitAbstract;

/**
 * Description of NewsLetterForm
 *
 * @author Christophe
 */
class NewsLetterForm extends SubmitAbstract {

    protected $formId = '92136cbb-f695-4766-bc98-a0c8423d2561'; //mandatory

    protected $formName = 'Newsletter'; // send to hubspot

    protected $varsMapping = [
        'email'             => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'email'  , 'format' =>\eteamsys\hubspot\Converter\LowerCaseConverter::class ],
        'postVars\input_3'  => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'rgpd'   , 'format' =>\eteamsys\hubspot\Converter\BooleanConverter::class ],
        'LANGUAGE_CODE'     => ['source' => 'Constant'                            , 'field' => 'langue' , 'format' => Converter\LanguageCodeConverter::class ],
    ];
    

}
