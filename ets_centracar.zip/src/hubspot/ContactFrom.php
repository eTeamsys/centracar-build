<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot;

use eteamsys\hubspot\form\SubmitAbstract;

/**
 * Description of ContactFrom
 *
 * @author Christophe
 */
class ContactFrom extends SubmitAbstract {

    protected $formId = 'b62f1f03-c3d7-498a-9ec8-31ac6a45c5ad'; //mandatory

    protected $formName = 'Demande de contact'; // send to hubspot

    protected $varsMapping = [
        'phone'              => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'phone'    , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],
        'postVars/input_8'   => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'lastname' , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],
        'postVars/input_6'   => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'qui_est_ce_que_vous_voulez_contacter_'    , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],
        'postVars/input_7'   => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'message'    , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],
        'LANGUAGE_CODE'      => ['source' => 'Constant'                            , 'field' => 'langue' , 'format' => Converter\LanguageCodeConverter::class ],
    ];

}