<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot;

/**
 * Description of PriceSearch
 *
 * @author Christophe
 */
class PriceSearch extends NewsLetterForm {

    protected $formId = '09d39ea6-a036-4f78-996d-d270693996b6'; //mandatory

    protected $formName = 'Simulateur "Calcul du prix maximal"'; // send to hubspot

    protected $varsMapping = [
        'postVars\refund'              => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'votre_mensualit_maximale'       , 'format' => \eteamsys\hubspot\Converter\NullConverter::class ],
        'postVars\duration'            => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'dur_e_maximale_du_financement'  , 'format' => \eteamsys\centracar\hubspot\Converter\DurationExtractConverter::class ],
        'postVars\deposit'             => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'acompte'                        , 'format' => \eteamsys\hubspot\Converter\NullConverter::class ],
    ];

}
