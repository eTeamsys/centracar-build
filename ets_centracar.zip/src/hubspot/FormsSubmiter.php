<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot;

/**
 * Description of FormsSubmitter
 *
 * @author Christophe
 */
class FormsSubmiter {
    
    /**
     * array of hubspot forms
     * with class as index and array of required fields as value
     * @var array
     */
    protected $forms = [
        \eteamsys\centracar\hubspot\Subscribe::class      => ['firstname' , 'lastname' , 'nom_d_utilisateur'],
        \eteamsys\centracar\hubspot\CarSearch::class      => ['mod_le_de_voiture_recherch_' , 'mod_le_s_de_voiture_recherch_s_' , 'marque_s_de_voiture_recherch_e_s_' , 'immatriculation_pd_' , 'kilom_trages_max_' , 'prix_vente'],
        \eteamsys\centracar\hubspot\NewsLetterForm::class => ['rgpd'],
        \eteamsys\centracar\hubspot\PhoneRecall::class    => ['phone'],
        \eteamsys\centracar\hubspot\PriceSearch::class    => ['votre_mensualit_maximale' , 'dur_e_maximale_du_financement' , 'acompte'],
        \eteamsys\centracar\hubspot\ContactFrom::class    => ['lastname' , 'message' , 'qui_est_ce_que_vous_voulez_contacter_'],
    ];
    
    /**
     * submit form chain of responsability
     * @return array
     */
    public function submit() {
        $result = [];
        
        foreach ($this->forms as $form => $required) {
            $result[$form] = null;
            /*@var \eteamsys\hubspot\form\SubmitAbstract $formInstance*/
            $formInstance = new $form;
            $formInstance->setVars();
            if($this->isAllow($required , $formInstance->getVars())) {
                $formInstance->setPortalId(PORTAL_ID)->submit();
                $result[$form] = $formInstance->getError();
            }

        }
        return $result;
        
    }
    
    /**
     * return trueif one of required fields is set in data
     * @param array $required
     * @param array $data
     * @return boolean
     */
    protected function isAllow($required, $data) {
        $output = false;
        foreach ($required as $field) {
            if(array_key_exists($field, $data) && !empty($data[$field])) {
                return true;
            }
        }
        return $output;
    }
    
    
}
