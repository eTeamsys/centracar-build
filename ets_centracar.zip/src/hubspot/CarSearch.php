<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot;

/**
 * Description of CarSearch
 *
 * @author Christophe
 */
class CarSearch extends NewsLetterForm {

    protected $formId = '77f497de-9804-4d40-a48d-d09cea0366c2'; //mandatory

    protected $formName = 'Simulateur "Trouvez ici la voiture de vos rêves !"'; // send to hubspot

    protected $varsMapping = [
        'postVars\type_carrosserie'                 => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'mod_le_de_voiture_recherch_'        , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],  
        'postVars\marque_modele\0\modele'           => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'mod_le_s_de_voiture_recherch_s_'    , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ], 
        'postVars\marque_modele\0\marque'           => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'marque_s_de_voiture_recherch_e_s_'  , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],  
        'postVars\date_premiere_immatriculation\0'  => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'immatriculation_pd_'                , 'format' =>\eteamsys\centracar\hubspot\Converter\YearConverter::class ],
        'postVars\kilometrage\1'                    => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'kilom_trages_max_'                  , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],
        'postVars\prix_vente\1'                     => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'prix_vente'                         , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],
    ];

}