<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot;

/**
 * Description of PhoneRecall
 *
 * @author Christophe
 */
class PhoneRecall extends NewsLetterForm {

    protected $formId = '62cdb2bd-e911-44a5-91d9-45eca42d8a67'; //mandatory

    protected $formName = 'Service de rappel'; // send to hubspot

    protected $varsMapping = [
        'postVars\input_2'  => ['source' => Extractor\CarAllianceExtractor::class , 'field' => 'phone'  , 'format' =>\eteamsys\hubspot\Converter\NullConverter::class ],
    ];

}
