<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar\hubspot\Extractor;

use \eteamsys\hubspot\Extractor\ExtractorAbstract;

/**
 * Description of CarAllianceSubmit
 *
 * @author Christophe
 */
class CarAllianceExtractor extends ExtractorAbstract 
{
    
    public function initData(array $data = []) {
        $Sniffer = new \eteamsys\centracar\PostSniffer();
        $this->data = $Sniffer->getPersistence()->get();
        return $this;
    }
    
}
