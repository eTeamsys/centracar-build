<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace eteamsys\centracar\persistence;
/**
 * Description of DataBasePersistence
 *
 * @author Christophe
 */
class DataBasePersistence implements PersistenceInterface {
    
    protected $tableBase = 'ets_formlogs';

    protected function getDb() {
        global $wpdb;
        return $wpdb;
    }
    
    protected function getPrefix() {
        global $table_prefix;
        return $table_prefix;
    }
    
    public function getUUID() {
        if(isset($_COOKIE['ets_uuid'])) {
            return $_COOKIE['ets_uuid'];
        }
        return $this->generateId();
    }
    
    protected function generateId() {
        $time = microtime(true);
        $unique_id = uniqid('ets_hs_', true); 
        $uuid = $unique_id . '.' . $time;
        setcookie('ets_uuid', $uuid , 0);
        return $uuid;
    }
    
    protected function getTableName() {
        return $this->getPrefix().$this->tableBase;
    }


    public function init() {
        $table = 'CREATE TABLE `'. $this->getTableName().'` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `uuid` varchar(255) NOT NULL,
                `email` varchar(50) DEFAULT NULL,
                `phone` varchar(20) DEFAULT NULL,
                `postVars` longtext NOT NULL,
                `postVars_history` longtext NULL,
                 PRIMARY KEY (`id`),
                 UNIQUE KEY `uuid` (`uuid`)
               ) ENGINE=MyISAM DEFAULT CHARSET=utf8';
        
        return $this->getDb()->query($table);
    }
    public function kill() {
    
       $drop =  'DROP TABLE `'. $this->getTableName().'`';
       return $this->getDb()->query($drop);
        
    }
    
    protected function arrayRecursiveDiff($aArray1, $aArray2) {
        $aReturn = array();

        foreach ($aArray1 as $mKey => $mValue) {
          if (array_key_exists($mKey, $aArray2)) {
            if (is_array($mValue)) {
              $aRecursiveDiff = $this->arrayRecursiveDiff($mValue, $aArray2[$mKey]);
              if (count($aRecursiveDiff)) { $aReturn[$mKey] = $aRecursiveDiff; }
            } else {
              if ($mValue != $aArray2[$mKey]) {
                $aReturn[$mKey] = $mValue;
              }
            }
          } else {
            $aReturn[$mKey] = $mValue;
          }
        }
        return $aReturn;
    } 
    
    public function get() {
        $select = 'SELECT * from `'. $this->getTableName().'` WHERE uuid="' .$this->getUUID(). '"';
        $output = (array)$this->getDb()->get_row($select);
        
        if(isset($output['postVars'])) {
            $output['postVars'] = json_decode($output['postVars'] , true);
        }
        
        if(isset($output['postVars_history'])) {
            $output['postVars_history'] = json_decode($output['postVars_history'] , true);
            if(is_array($output['postVars_history'])){
                $output['postVars'] = $this->arrayRecursiveDiff($output['postVars'], $output['postVars_history']);
            }
        }

        
        return $output;
        
        
    }
    
    public function search($id) {
        $select = 'SELECT * from `'. $this->getTableName().'` WHERE uuid="' .$id. '"';
        $output = (array)$this->getDb()->get_row($select);
        
        if(isset($output['postVars'])) {
            $output['postVars'] = json_decode($output['postVars'] , true);
        }
        
        if(isset($output['postVars_history'])) {
            $output['postVars_history'] = json_decode($output['postVars_history'] , true);
            if(is_array($output['postVars_history'])){
                $output['postVars_diff'] = $this->arrayRecursiveDiff($output['postVars'], $output['postVars_history']);
            }
        }

        
        return $output;
    }

    public function has() {
        $select = 'SELECT count(*) as cpt from `'. $this->getTableName().'` WHERE uuid="' .$this->getUUID(). '"';
        
        return ($this->getDb()->get_row($select)['cpt'] > 0 );
    }

    public function set($email , $phone, $data) {
        
        $postVars = esc_sql(json_encode($data));
        
        $update = 'INSERT INTO '. $this->getTableName() .' (`uuid`, `email`, `phone`, `postVars`) '
                . "VALUES ('". $this->getUUID() ."' , '".$email."' , '". $phone ."' ,'". $postVars ."') ";
        
        $onDuplicate = ["`uuid`= '". $this->getUUID() ."'"];
        
        if(!is_null($email)) {
            $onDuplicate[] = "email='" .$email. "'" ;
        }
        
        if(!is_null($phone)) {
            $onDuplicate[] = "phone='" .$phone. "'" ;
        }
        
        $update .= "ON DUPLICATE KEY UPDATE " . implode(' , ', $onDuplicate);
        
        $postVarsInsert = 'UPDATE '. $this->getTableName() .' SET postVars="'. $postVars .'" WHERE `uuid`= "'. $this->getUUID() .'"';
        
        $this->getDb()->query($update);
        $this->getDb()->query($postVarsInsert);
        return true;
        
    }
    
    public function history() {
        
        $postVarsHistory = 'UPDATE '. $this->getTableName() .' SET postVars_history=postVars WHERE `uuid`= "'. $this->getUUID() .'"';
        $this->getDb()->query($postVarsHistory);
        return true;
        
    }
    
    
}
