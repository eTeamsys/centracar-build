<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace eteamsys\centracar\persistence;
/**
 * Description of PersistenceInterface
 *
 * @author Christophe
 */
interface PersistenceInterface {
    
    public function init();
    
    public function kill();

    public function get();
    
    public function has();
    
    public function set($email , $phone, $data);
    
}
