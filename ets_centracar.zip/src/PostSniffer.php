<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace eteamsys\centracar;

/**
 * Description of PostSniffer
 *
 * @author Christophe
 */
class PostSniffer {
   
    /**
     *
     * @var persistence\PersistenceInterface 
     */
    protected $persistence;

    protected $defaultPersistenceClass = '\\eteamsys\\centracar\\persistence\\DataBasePersistence';
    
    public function init() {
        $this->getPersistence()->init();
    }
    
    public function kill() {
        $this->getPersistence()->kill();
    }

        /**
     * 
     * @param \eteamsys\centracar\persistence\PersistenceInterface $persistence
     * @return $this
     */
    public function setPersistence(persistence\PersistenceInterface $persistence) {
        $this->persistence = $persistence;
        return $this;
    }
    
    /**
     * 
     * @return persistence\PersistenceInterface
     */
    public function getPersistence() {
        if(is_null($this->persistence)) {
            $this->persistence = new $this->defaultPersistenceClass;
        }
        return $this->persistence;
    }
    
    /**
     * 
     * @param array $data
     * @return mixed
     */
    protected function scanForEmail($data) {
        $email = '';
        foreach($data as $key => $value) {
            if(is_array($value)) {
                $email = $this->scanForEmail($value);
                if($email != false) {
                    return $email;
                }
            } elseif(filter_var($value , FILTER_VALIDATE_EMAIL)) {
                 return $value;
            }
        }
        return null;
    }
    
    /**
     * 
     * @param array $data
     * @return mixed
     */
    protected function phoneSumitted($data) {
        if(isset($data['input_2'])) {
            return $data['input_2'];
        }
        return null;
    }
    
    /**
     * 
     * @param array $data
     * @return type
     */
    protected function mergeData($data) {
        
        $oldData = $this->getPersistence()->get();
        
        if(!empty($oldData) && isset($oldData['postVars']) && !empty($oldData['postVars'])) {
            return array_replace_recursive( $oldData['postVars'] , $data );
        }
        return $data;
    }
    
    /**
     * 
     * @return boolean
     */
    public function sniff() {

        if((isset($_SERVER['HTTP_METHOD']) && strtoupper($_SERVER['HTTP_METHOD']) == 'POST') || strtoupper($_SERVER['REQUEST_METHOD']) == 'POST') {
            
            $entryData = $_REQUEST;
            
            if(isset($_COOKIE['financing'])) {
                $entryData = array_merge($entryData , json_decode($_COOKIE['financing'] , true));
            }
            
            $email = $this->scanForEmail($entryData);
            $phone = $this->phoneSumitted($entryData);
            
            $data = $this->mergeData($entryData);
            
            $this->getPersistence()->set($email, $phone, $data);
            
            do_action('ets_centracar_sendforms' , $this->getPersistence()->get());
            
           return true;
        }
        return false;
    }
    
}
