<?php

/**
 * @wordpress-plugin
 * Plugin Name:       Centracar Specifics feature
 * Plugin URI:        
 * Description:       Centracar user managment and Specifics feature
 * Version:           0.0.1
 * Author:            eTeamsys
 * Author URI:        https://www.eteamsys.com
 * License:           GPL-2.0
 * License URI:       https://opensource.org/licenses/GPL-2.0
 * Text Domain:       ets_centracar
 * Domain Path:       eteamsys
 */

include_once 'vendor/autoload.php';

define('PORTAL_ID' , '6672575');

define('FORM_BASE_URL' , 'https://forms.hubspot.com/uploads/form/v2/');

define('LANGUAGE_CODE' , get_locale());

$Sniffer = new \eteamsys\centracar\PostSniffer();

register_activation_hook(__FILE__ , [$Sniffer , 'init']);

register_deactivation_hook(__FILE__ , [$Sniffer , 'kill']);

add_action('ets_centracar_sendforms' , 'submitHubspotForm' , 10, 2  );

function submitHubspotForm($params) {
    
    global $Sniffer;
    
    if(!empty($params['email'])) {
        
        $submitter = new \eteamsys\centracar\hubspot\FormsSubmiter();
        $result = $submitter->submit();
        $Sniffer->getPersistence()->history();
        
    }

}

$Sniffer->sniff();

/**
 * add tracking to header
 */
function hook_javascript() {
    
    if(($tracking = get_option('ets_centracar_tracking_code')) !=false) {
        echo $tracking;
    }
    
}
add_action('wp_head', 'hook_javascript' ,  1500 );

/**
 * tracking options
 */
function ets_centracar_register_options_page() {
    
  register_setting('ets_centracar_group' , 'ets_centracar_tracking_code' );
  add_options_page('Tracking Hubspot', 'Tracking Hubspot', 'manage_options', 'ets_centracar', 'ets_centracar_options_page');
}
add_action('admin_menu', 'ets_centracar_register_options_page');

function ets_centracar_options_page()
{
?>
  <div>
  <h2>Tracking Hubspot</h2>
  <form method="post" action="options.php">
  <?php settings_fields( 'ets_centracar_group' ); ?>
  <h3>code de tracking</h3>
  <table>
  <tr valign="top">
  <th scope="row"><label for="ets_centracar_tracking_code">tracking</label></th>
  <td><textarea rows="10" cols="50"  id="ets_centracar_tracking_code" name="ets_centracar_tracking_code"  ><?php echo get_option('ets_centracar_tracking_code'); ?></textarea></td>
  </tr>
  </table>
  <?php  submit_button(); ?>
  </form>
  </div>
<div>
    <h3>code de tracking</h3>
    <form action="" method="post" >
        <input type="text" name="id" />
        <input type="submit" name="send" value="chercher" />
    </form>
    
</div>
<?php if(isset($_POST['id'])): ?>
    <?php global $Sniffer; ?>
    <?php $data = $Sniffer->getPersistence()->search($_POST['id']); ?>
<table>
    <tr>
        <td><?php echo $data['email'];  ?></td><td><?php echo $data['phone'];  ?></td>
    </tr>
    <tr>
        <td><pre><?php var_export($data['postVars']);  ?></pre></td><td><pre><?php echo var_export($data['postVars_history']);  ?></pre></td>
    </tr>
    <tr>
        <td colspan="2"><pre><?php var_export($data['postVars_diff']);  ?></pre></td>
    </tr>
</table>
<?php endif; ?>
<?php
} ?>